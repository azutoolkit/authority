# User Info

{% swagger src="../../.gitbook/assets/openid.yaml" path="/userinfo" method="get" %}
[openid.yaml](../../.gitbook/assets/openid.yaml)
{% endswagger %}

{% swagger src="../../.gitbook/assets/openid.yaml" path="/userinfo" method="post" %}
[openid.yaml](../../.gitbook/assets/openid.yaml)
{% endswagger %}
