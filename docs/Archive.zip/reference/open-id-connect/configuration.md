# Configuration

{% swagger src="../../.gitbook/assets/openid.yaml" path="undefined" method="undefined" %}
[openid.yaml](../../.gitbook/assets/openid.yaml)
{% endswagger %}

{% swagger src="../../.gitbook/assets/openid.yaml" path="/.well-known/jwks.json" method="get" %}
[openid.yaml](../../.gitbook/assets/openid.yaml)
{% endswagger %}

