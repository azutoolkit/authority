
# Configuration

## Environment Variables

- `DATABASE_URL`: The URL for connecting to your database.
- `OAUTH_CLIENT_ID`: The client ID for OAuth.
- `OAUTH_CLIENT_SECRET`: The client secret for OAuth.

Adjust these settings in your `.env.local` file as necessary.
