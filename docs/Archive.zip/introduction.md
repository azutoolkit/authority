
# Authority Documentation

## Introduction

Authority is an authentication solution built with the Crystal programming language. It offers robust authentication features, including OAuth grants and customizable authentication logic. The following documentation will guide you through the installation, configuration, and usage of the Authority project.
