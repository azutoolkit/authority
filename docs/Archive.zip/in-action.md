# In Action

### Authorization Flow

{% embed url="https://user-images.githubusercontent.com/1685772/140772737-179dd2e4-0eaa-4915-a942-5e0fe48f0124.mp4" %}
